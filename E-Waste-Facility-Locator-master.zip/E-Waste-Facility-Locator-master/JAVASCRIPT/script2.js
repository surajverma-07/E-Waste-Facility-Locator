document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const message = document.getElementById("message");

    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const email = document.getElementById("email").value;
        const password = document.getElementById("password").value;

        // You can implement your authentication logic here.
        // For a simple example, let's check if the username and password are both "admin".
        if (email === "ojaswat@gmail.com" && password === "1234567" || email==="imfosys@gmail.com" && password ==="1234"|| email==="palak@gmail.com" && password === "1607" || email==="surajkumarverma662@gmail.com" && password==="7777777" || username==="vikas@gmail.com" && password==="55555")
        { 
            window.location.href = 'recycle_dashboard.html';
        } 
        else {
            message.textContent = "Invalid username or password.";
        }
    });
});
