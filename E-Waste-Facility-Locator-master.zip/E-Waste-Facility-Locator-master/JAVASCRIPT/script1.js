document.addEventListener("DOMContentLoaded", function () {
    const loginForm = document.getElementById("loginForm");
    const message = document.getElementById("message");

    loginForm.addEventListener("submit", function (e) {
        e.preventDefault();

        const username = document.getElementById("username").value;
        const password = document.getElementById("password").value;

        // You can implement your authentication logic here.
        // For a simple example, let's check if the username and password are both "admin".
        if (username === "ojaswat" && password === "1234567" || username==="palak" && password === "1607" || username==="suraj" && password==="7777777" || username==="vikas" && password==="55555")
        { 
            window.location.href = 'home.html';
        } 
        else {
            message.textContent = "Invalid username or password.";
        }
    });
});
